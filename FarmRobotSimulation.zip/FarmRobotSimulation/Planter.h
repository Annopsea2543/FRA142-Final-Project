#ifndef PLANTER_H
#define PLANTER_H

#include "Robot.h"

class Planter : public Robot {
public:
    Planter(const std::string& name, int x, int y);
    std::string getType() const override;
    std::string getTaskType() const override;
protected:
    void performWork() override;
};

#endif
