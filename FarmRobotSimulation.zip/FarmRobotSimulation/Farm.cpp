#include "Farm.h"
#include <iostream>
#include <iomanip>
#include <algorithm>

Farm::Farm() : timestep(0) {}

void Farm::addRobot(std::unique_ptr<Robot> robot) {
    if (robot) robots.push_back(std::move(robot));
}

void Farm::addTask(const Task& task) { tasks.push_back(task); }

void Farm::assignTasks() {
    for (const auto& robot : robots) {
        if (robot->hasTask() || robot->getStatus() == "CHARGING") continue;
        for (auto& task : tasks) {
            if (task.isCompleted()) continue;
            bool alreadyAssigned = false;
            for (const auto& other : robots) {
                if (other->getTaskId() == task.getId()) {
                    alreadyAssigned = true;
                    break;
                }
            }
            if (!alreadyAssigned && robot->assignTask(&task)) break;
        }
    }
}

bool Farm::allTasksCompleted() const {
    return std::all_of(tasks.begin(), tasks.end(), [](const Task& task) {
        return task.isCompleted();
    });
}

void Farm::showGrid() const {
    char grid[HEIGHT][WIDTH];
    for (int y = 0; y < HEIGHT; ++y)
        for (int x = 0; x < WIDTH; ++x) grid[y][x] = '.';

    grid[CHARGER_Y][CHARGER_X] = 'C';
    for (const auto& task : tasks) {
        if (!task.isCompleted()) grid[task.getY()][task.getX()] = 'T';
    }
    for (const auto& robot : robots) {
        char marker = robot->getName().empty() ? 'R' : robot->getName().back();
        grid[robot->getY()][robot->getX()] = marker;
    }

    std::cout << "Farm Grid (10 x 5)\n";
    for (int y = 0; y < HEIGHT; ++y) {
        for (int x = 0; x < WIDTH; ++x) std::cout << grid[y][x] << ' ';
        std::cout << '\n';
    }
    std::cout << "C = Charging Station, T = Task, R1/R2/R3 = Robot\n";
}

void Farm::showStatus() const {
    std::cout << "\nRobot Status\n";
    for (const auto& robot : robots) {
        std::cout << std::left << std::setw(4) << robot->getName()
                  << " Type: " << std::setw(7) << robot->getType()
                  << " Pos: (" << robot->getX() << ',' << robot->getY() << ')'
                  << " Battery: " << std::setw(3) << robot->getBattery() << '%'
                  << " Status: " << std::setw(8) << robot->getStatus()
                  << " Task: " << robot->getTaskId() << '\n';
    }

    std::cout << "\nTask Status\n";
    for (const auto& task : tasks) {
        std::cout << task.getId() << " " << std::setw(5) << task.getType()
                  << " Pos: (" << task.getX() << ',' << task.getY() << ')'
                  << " Progress: " << task.getProgress() << '/' << task.getDuration()
                  << " Status: " << task.getStatus() << '\n';
    }
}

void Farm::run(int maxTimesteps) {
    std::cout << "=== FARM ROBOT SIMULATION ===\n";
    for (timestep = 1; timestep <= maxTimesteps; ++timestep) {
        assignTasks();
        std::cout << "\n========== TIMESTEP " << timestep << " ==========\n";
        for (const auto& robot : robots) robot->update(CHARGER_X, CHARGER_Y);
        showGrid();
        showStatus();
        if (allTasksCompleted()) {
            std::cout << "\nAll tasks completed!\n";
            break;
        }
    }
    if (!allTasksCompleted()) std::cout << "\nSimulation stopped: timestep limit reached.\n";
    showSummary();
}

void Farm::showSummary() const {
    int completed = 0;
    for (const auto& task : tasks) if (task.isCompleted()) ++completed;

    std::cout << "\n========== SIMULATION SUMMARY ==========\n";
    std::cout << "Tasks completed: " << completed << '/' << tasks.size() << '\n';
    std::cout << "Timesteps used: " << std::min(timestep, 200) << '\n';
    for (const auto& robot : robots) {
        std::cout << robot->getName() << " completed tasks: "
                  << robot->getCompletedTasks() << '\n';
    }
}
