#ifndef FARM_H
#define FARM_H

#include <memory>
#include <vector>
#include "Robot.h"

class Farm {
private:
    static constexpr int WIDTH = 10;
    static constexpr int HEIGHT = 5;
    static constexpr int CHARGER_X = 0;
    static constexpr int CHARGER_Y = 4;

    std::vector<std::unique_ptr<Robot>> robots;
    std::vector<Task> tasks;
    int timestep;

    void assignTasks();
    bool allTasksCompleted() const;
    void showGrid() const;
    void showStatus() const;

public:
    Farm();
    void addRobot(std::unique_ptr<Robot> robot);
    void addTask(const Task& task);
    void run(int maxTimesteps = 200);
    void showSummary() const;
};

#endif
