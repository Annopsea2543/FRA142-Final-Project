#include "Task.h"

Task::Task(const std::string& taskId, const std::string& taskType,
           int taskX, int taskY, int taskDuration)
    : id(taskId), type(taskType), x(taskX), y(taskY),
      duration(taskDuration), progress(0), completed(false) {}

const std::string& Task::getId() const { return id; }
const std::string& Task::getType() const { return type; }
int Task::getX() const { return x; }
int Task::getY() const { return y; }
int Task::getProgress() const { return progress; }
int Task::getDuration() const { return duration; }
bool Task::isCompleted() const { return completed; }

void Task::performStep() {
    if (completed) return;
    ++progress;
    if (progress >= duration) completed = true;
}

std::string Task::getStatus() const {
    if (completed) return "DONE";
    if (progress > 0) return "IN_PROGRESS";
    return "WAITING";
}
