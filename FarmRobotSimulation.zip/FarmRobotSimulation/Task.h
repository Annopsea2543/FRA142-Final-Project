#ifndef TASK_H
#define TASK_H

#include <string>

class Task {
private:
    std::string id;
    std::string type;
    int x;
    int y;
    int duration;
    int progress;
    bool completed;

public:
    Task(const std::string& id, const std::string& type,
         int x, int y, int duration);

    const std::string& getId() const;
    const std::string& getType() const;
    int getX() const;
    int getY() const;
    int getProgress() const;
    int getDuration() const;
    bool isCompleted() const;
    void performStep();
    std::string getStatus() const;
};

#endif
