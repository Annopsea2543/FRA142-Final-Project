#ifndef ROBOT_H
#define ROBOT_H

#include <string>
#include "Task.h"

class Robot {
private:
    std::string name;
    int x;
    int y;
    int battery;
    std::string status;
    Task* currentTask;
    bool returningToCharge;
    int completedTasks;

protected:
    virtual void performWork() = 0;

public:
    Robot(const std::string& name, int x, int y);
    virtual ~Robot() = default;

    const std::string& getName() const;
    int getX() const;
    int getY() const;
    int getBattery() const;
    const std::string& getStatus() const;
    int getCompletedTasks() const;
    bool hasTask() const;
    std::string getTaskId() const;
    virtual std::string getType() const = 0;
    virtual std::string getTaskType() const = 0;

    bool assignTask(Task* task);
    void update(int chargerX, int chargerY);
};

#endif
