#include "Robot.h"
#include <algorithm>
#include <cstdlib>

Robot::Robot(const std::string& robotName, int startX, int startY)
    : name(robotName), x(startX), y(startY), battery(100), status("IDLE"),
      currentTask(nullptr), returningToCharge(false), completedTasks(0) {}

const std::string& Robot::getName() const { return name; }
int Robot::getX() const { return x; }
int Robot::getY() const { return y; }
int Robot::getBattery() const { return battery; }
const std::string& Robot::getStatus() const { return status; }
int Robot::getCompletedTasks() const { return completedTasks; }
bool Robot::hasTask() const { return currentTask != nullptr; }
std::string Robot::getTaskId() const { return currentTask ? currentTask->getId() : "-"; }

bool Robot::assignTask(Task* task) {
    if (!task || currentTask || returningToCharge || task->isCompleted()) return false;
    if (task->getType() != getTaskType()) return false;
    currentTask = task;
    return true;
}

void Robot::update(int chargerX, int chargerY) {
    // Battery threshold: return to charger when battery reaches 20% or less.
    if (battery <= 20) returningToCharge = true;

    if (returningToCharge) {
        if (x != chargerX || y != chargerY) {
            if (x != chargerX) x += (x < chargerX ? 1 : -1);
            else if (y != chargerY) y += (y < chargerY ? 1 : -1);
            battery = std::max(0, battery - 1);
            status = "MOVING";
        } else {
            returningToCharge = false;
            status = "CHARGING";
        }
        return;
    }

    if (status == "CHARGING") {
        battery = std::min(80, battery + 20);
        if (battery >= 80) status = "IDLE";
        return;
    }

    if (!currentTask) {
        status = "IDLE";
        return;
    }

    if (x != currentTask->getX() || y != currentTask->getY()) {
        // Move along X first, then Y; one grid cell per timestep.
        if (x != currentTask->getX()) x += (x < currentTask->getX() ? 1 : -1);
        else if (y != currentTask->getY()) y += (y < currentTask->getY() ? 1 : -1);
        battery = std::max(0, battery - 1);
        status = "MOVING";
        return;
    }

    status = "WORKING";
    performWork();
    currentTask->performStep();
    battery = std::max(0, battery - 5);

    if (currentTask->isCompleted()) {
        currentTask = nullptr;
        ++completedTasks;
        status = "IDLE";
    }
}
