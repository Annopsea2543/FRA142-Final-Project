#include "Waterer.h"
#include <iostream>

Waterer::Waterer(const std::string& name, int x, int y) : Robot(name, x, y) {}
std::string Waterer::getType() const { return "Waterer"; }
std::string Waterer::getTaskType() const { return "WATER"; }
void Waterer::performWork() { std::cout << "  Watering crops...\n"; }
