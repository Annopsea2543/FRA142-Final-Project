#ifndef WATERER_H
#define WATERER_H

#include "Robot.h"

class Waterer : public Robot {
public:
    Waterer(const std::string& name, int x, int y);
    std::string getType() const override;
    std::string getTaskType() const override;
protected:
    void performWork() override;
};

#endif
