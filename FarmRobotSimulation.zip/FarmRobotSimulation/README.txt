FARM ROBOT SIMULATION (C++17)

Files:
  Task.h / Task.cpp         Task model
  Robot.h / Robot.cpp       Abstract Robot base class
  Planter.h / Planter.cpp   Planter robot
  Waterer.h / Waterer.cpp   Waterer robot
  Farm.h / Farm.cpp         Farm simulation and task assignment
  main.cpp                  Program entry point and basic unit tests

Compile:
  g++ -std=c++17 -Wall -Wextra -pedantic main.cpp Task.cpp Robot.cpp Planter.cpp Waterer.cpp Farm.cpp -o farm

Run simulation:
  ./farm

Run basic unit tests:
  ./farm --test

Simulation rules:
  - 10 x 5 grid
  - Robots move one cell per timestep, X axis first then Y axis
  - Moving costs 1% battery; working costs 5% per timestep
  - At 20% battery or lower, robot returns to charger at (0,4)
  - Charging adds 20% per timestep until 80%
