#include <iostream>
#include <cassert>
#include <memory>
#include "Farm.h"
#include "Planter.h"
#include "Waterer.h"

void runUnitTests() {
    Task task("T1", "PLANT", 2, 1, 2);
    assert(task.getStatus() == "WAITING");
    task.performStep();
    assert(task.getStatus() == "IN_PROGRESS");
    task.performStep();
    assert(task.isCompleted());
    assert(task.getStatus() == "DONE");

    Planter planter("R1", 1, 0);
    assert(planter.getType() == "Planter");
    assert(planter.getTaskType() == "PLANT");
    assert(planter.getBattery() == 100);

    Waterer waterer("R3", 8, 0);
    assert(waterer.getType() == "Waterer");
    assert(waterer.getTaskType() == "WATER");

    std::cout << "All basic unit tests passed.\n";
}

int main(int argc, char* argv[]) {
    if (argc > 1 && std::string(argv[1]) == "--test") {
        runUnitTests();
        return 0;
    }

    Farm farm;
    farm.addRobot(std::make_unique<Planter>("R1", 1, 0));
    farm.addRobot(std::make_unique<Planter>("R2", 3, 0));
    farm.addRobot(std::make_unique<Waterer>("R3", 8, 0));

    farm.addTask(Task("T1", "PLANT", 2, 1, 2));
    farm.addTask(Task("T2", "WATER", 5, 1, 2));
    farm.addTask(Task("T3", "PLANT", 6, 2, 2));
    farm.addTask(Task("T4", "WATER", 7, 3, 2));
    farm.addTask(Task("T5", "PLANT", 3, 4, 2));

    farm.run();
    return 0;
}
