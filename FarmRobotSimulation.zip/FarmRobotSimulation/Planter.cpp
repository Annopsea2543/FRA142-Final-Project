#include "Planter.h"
#include <iostream>

Planter::Planter(const std::string& name, int x, int y) : Robot(name, x, y) {}
std::string Planter::getType() const { return "Planter"; }
std::string Planter::getTaskType() const { return "PLANT"; }
void Planter::performWork() { std::cout << "  Planting seeds...\n"; }
